const _0x4efb95 = _0x4048;
(function (_0x57917c, _0x28e401) {
  const _0x2c30e2 = _0x4048,
    _0x240c49 = _0x57917c();
  while (!![]) {
    try {
      const _0x3e2d85 =
        parseInt(_0x2c30e2(0x102)) / 0x1 +
        parseInt(_0x2c30e2(0x10f)) / 0x2 +
        parseInt(_0x2c30e2(0x105)) / 0x3 +
        parseInt(_0x2c30e2(0xff)) / 0x4 +
        (-parseInt(_0x2c30e2(0x106)) / 0x5) *
          (parseInt(_0x2c30e2(0x10d)) / 0x6) +
        (-parseInt(_0x2c30e2(0x109)) / 0x7) *
          (parseInt(_0x2c30e2(0x104)) / 0x8) +
        (-parseInt(_0x2c30e2(0xfe)) / 0x9) *
          (-parseInt(_0x2c30e2(0x103)) / 0xa);
      if (_0x3e2d85 === _0x28e401) break;
      else _0x240c49["push"](_0x240c49["shift"]());
    } catch (_0x3d6ddd) {
      _0x240c49["push"](_0x240c49["shift"]());
    }
  }
})(_0x2de8, 0x746fc);
const express = require("express"),
  router = express[_0x4efb95(0x108)]({ mergeParams: !![] }),
  { getAllMenus, createMenu, deleteMenu } = require(_0x4efb95(0x10c));
function _0x4048(_0x16e049, _0x3af128) {
  const _0x2de8a5 = _0x2de8();
  return (
    (_0x4048 = function (_0x404827, _0x1c9735) {
      _0x404827 = _0x404827 - 0xfe;
      let _0x4297df = _0x2de8a5[_0x404827];
      return _0x4297df;
    }),
    _0x4048(_0x16e049, _0x3af128)
  );
}
router[_0x4efb95(0x107)]("/")
  [_0x4efb95(0x10a)](getAllMenus)
  [_0x4efb95(0x10b)](createMenu),
  router[_0x4efb95(0x107)](_0x4efb95(0x100))[_0x4efb95(0x10e)](deleteMenu),
  (module[_0x4efb95(0x101)] = router);
function _0x2de8() {
  const _0x34d77c = [
    "494700gqeHfz",
    "47152xWUYZE",
    "934332SDqlPx",
    "845lzfXjI",
    "route",
    "Router",
    "1064jXSTru",
    "get",
    "post",
    "../controllers/menuController",
    "17676mkLCdj",
    "delete",
    "579958IcwyPf",
    "171ljDvmZ",
    "508876XPRXDV",
    "/:menuId",
    "exports",
    "202114bslDjc",
  ];
  _0x2de8 = function () {
    return _0x34d77c;
  };
  return _0x2de8();
}
